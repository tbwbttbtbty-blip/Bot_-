const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');
const path = require('path');
const https = require('https');

// ============================================================
// CONFIG
// ============================================================
const TOKEN = process.env.BOT_TOKEN || '7901718338:AAF47zdZP1z0e71xYpyIggmUt1DrSO5KPBo';
const bot = new TelegramBot(TOKEN, { polling: true });

const DATA_DIR = path.join(__dirname, 'data');
const USERS_FILE = path.join(DATA_DIR, 'users.json');
const ADMINS_FILE = path.join(DATA_DIR, 'admins.json');
const BANNED_FILE = path.join(DATA_DIR, 'banned.json');
const SETTINGS_FILE = path.join(DATA_DIR, 'settings.json');

// ============================================================
// DATA HELPERS
// ============================================================
function ensureDir() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
}
ensureDir();

function readJSON(file, defaultVal = []) {
  try {
    if (!fs.existsSync(file)) fs.writeFileSync(file, JSON.stringify(defaultVal, null, 2));
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch { return defaultVal; }
}

function writeJSON(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2), 'utf8');
}

let users = readJSON(USERS_FILE, []);
let admins = readJSON(ADMINS_FILE, ['ADMIN_USER_ID']); // ضع معرفك هنا
let banned = readJSON(BANNED_FILE, []);
let settings = readJSON(SETTINGS_FILE, { broadcastActive: false });

function saveUsers() { writeJSON(USERS_FILE, users); }
function saveAdmins() { writeJSON(ADMINS_FILE, admins); }
function saveBanned() { writeJSON(BANNED_FILE, banned); }
function saveSettings() { writeJSON(SETTINGS_FILE, settings); }

function getUser(id) { return users.find(u => u.id === id); }
function isAdmin(id) { return admins.includes(id); }
function isBanned(id) { return banned.includes(id); }

function registerUser(msg) {
  const id = msg.from.id;
  if (!getUser(id)) {
    users.push({ id, username: msg.from.username || '', first_name: msg.from.first_name || '', joined: new Date().toISOString() });
    saveUsers();
  }
}

// ============================================================
// INLINE KEYBOARD BUILDER with BLUE style (Bot API 9.4+)
// ============================================================
function btn(text, callback_data, style = 'primary') {
  const b = { text, callback_data };
  if (style) b.style = style;
  return b;
}

function urlBtn(text, url, style = 'primary') {
  const b = { text, url };
  if (style) b.style = style;
  return b;
}

function row(...buttons) { return buttons; }
function markup(...rows) { return { reply_markup: { inline_keyboard: rows } }; }

// ============================================================
// CONSTANTS
// ============================================================

// قائمة الأنبياء الكاملة (25 نبياً)
const PROPHETS = [
  { id: 'prophet_adam', name: 'آدم عليه السلام', videoId: 'hC-hfDGgMVg' },
  { id: 'prophet_idris', name: 'إدريس عليه السلام', videoId: 'beQDZCnTVXM' },
  { id: 'prophet_nuh', name: 'نوح عليه السلام', videoId: 'At7u6PB0f9s' },
  { id: 'prophet_hud', name: 'هود عليه السلام', videoId: 'beQDZCnTVXM' },
  { id: 'prophet_salih', name: 'صالح عليه السلام', videoId: 'beQDZCnTVXM' },
  { id: 'prophet_ibrahim', name: 'إبراهيم عليه السلام', videoId: 'qd_AeukZTS0' },
  { id: 'prophet_lut', name: 'لوط عليه السلام', videoId: 'beQDZCnTVXM' },
  { id: 'prophet_ismail', name: 'إسماعيل عليه السلام', videoId: 'beQDZCnTVXM' },
  { id: 'prophet_ishaq', name: 'إسحاق عليه السلام', videoId: 'beQDZCnTVXM' },
  { id: 'prophet_yakub', name: 'يعقوب عليه السلام', videoId: 'beQDZCnTVXM' },
  { id: 'prophet_yusuf', name: 'يوسف عليه السلام', videoId: 'beQDZCnTVXM' },
  { id: 'prophet_shuaib', name: 'شعيب عليه السلام', videoId: 'beQDZCnTVXM' },
  { id: 'prophet_ayub', name: 'أيوب عليه السلام', videoId: 'beQDZCnTVXM' },
  { id: 'prophet_dhulKifl', name: 'ذو الكفل عليه السلام', videoId: 'beQDZCnTVXM' },
  { id: 'prophet_musa', name: 'موسى عليه السلام', videoId: 'beQDZCnTVXM' },
  { id: 'prophet_harun', name: 'هارون عليه السلام', videoId: 'beQDZCnTVXM' },
  { id: 'prophet_dawud', name: 'داود عليه السلام', videoId: 'beQDZCnTVXM' },
  { id: 'prophet_sulaiman', name: 'سليمان عليه السلام', videoId: '2EheHgzU0Jg' },
  { id: 'prophet_ilyas', name: 'إلياس عليه السلام', videoId: 'beQDZCnTVXM' },
  { id: 'prophet_alYasa', name: 'اليسع عليه السلام', videoId: 'beQDZCnTVXM' },
  { id: 'prophet_yunus', name: 'يونس عليه السلام', videoId: 'beQDZCnTVXM' },
  { id: 'prophet_zakaria', name: 'زكريا عليه السلام', videoId: 'beQDZCnTVXM' },
  { id: 'prophet_yahya', name: 'يحيى عليه السلام', videoId: 'beQDZCnTVXM' },
  { id: 'prophet_isa', name: 'عيسى عليه السلام', videoId: 'beQDZCnTVXM' },
  { id: 'prophet_muhammad', name: 'محمد ﷺ', videoId: 'beQDZCnTVXM' },
];

// أسماء السور (114)
const SURAH_NAMES = [
  'الفاتحة','البقرة','آل عمران','النساء','المائدة','الأنعام','الأعراف','الأنفال','التوبة','يونس',
  'هود','يوسف','الرعد','إبراهيم','الحجر','النحل','الإسراء','الكهف','مريم','طه',
  'الأنبياء','الحج','المؤمنون','النور','الفرقان','الشعراء','النمل','القصص','العنكبوت','الروم',
  'لقمان','السجدة','الأحزاب','سبأ','فاطر','يس','الصافات','ص','الزمر','غافر',
  'فصلت','الشورى','الزخرف','الدخان','الجاثية','الأحقاف','محمد','الفتح','الحجرات','ق',
  'الذاريات','الطور','النجم','القمر','الرحمن','الواقعة','الحديد','المجادلة','الحشر','الممتحنة',
  'الصف','الجمعة','المنافقون','التغابن','الطلاق','التحريم','الملك','القلم','الحاقة','المعارج',
  'نوح','الجن','المزمل','المدثر','القيامة','الإنسان','المرسلات','النبأ','النازعات','عبس',
  'التكوير','الانفطار','المطففين','الانشقاق','البروج','الطارق','الأعلى','الغاشية','الفجر','البلد',
  'الشمس','الليل','الضحى','الشرح','التين','العلق','القدر','البينة','الزلزلة','العاديات',
  'القارعة','التكاثر','العصر','الهمزة','الفيل','قريش','الماعون','الكوثر','الكافرون','النصر',
  'المسد','الإخلاص','الفلق','الناس'
];

// القراء مع روابط api.alquran.cloud (مستقرة)
const RECITERS = [
  { id: 'ar.alafasy', name: 'مشاري العفاسي' },
  { id: 'ar.abdulsamad', name: 'عبدالباسط عبدالصمد' },
  { id: 'ar.sudais', name: 'السديس' },
  { id: 'ar.husary', name: 'الحصري' },
  { id: 'ar.ghamdi', name: 'سعد الغامدي' },
  { id: 'ar.shatri', name: 'أبو بكر الشاطري' },
  { id: 'ar.shuraym', name: 'شريم' },
  { id: 'ar.ahmedajamy', name: 'أحمد العجمي' },
];

// ============================================================
// FUNCTIONS
// ============================================================

/** إرسال أو تحرير رسالة بالردود */
async function sendOrEdit(chatId, msgId, text, kb) {
  try {
    if (msgId) {
      await bot.editMessageText(text, { chat_id: chatId, message_id: msgId, ...kb, parse_mode: 'HTML' });
    } else {
      await bot.sendMessage(chatId, text, { ...kb, parse_mode: 'HTML' });
    }
  } catch (e) {
    if (e.message && e.message.includes('message is not modified')) return;
    try { await bot.sendMessage(chatId, text, { ...kb, parse_mode: 'HTML' }); } catch (e2) {}
  }
}

/** جلب نص السورة من API */
async function getSurahText(surahNum) {
  return new Promise((resolve) => {
    const url = `https://api.alquran.cloud/v1/surah/${surahNum}`;
    https.get(url, (res) => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => {
        try {
          const json = JSON.parse(data);
          if (json.data) {
            const ayahs = json.data.ayahs.map(a => a.text).join(' ');
            resolve(ayahs);
          } else resolve(null);
        } catch { resolve(null); }
      });
    }).on('error', () => resolve(null));
  });
}

/** الحصول على رابط الصوت من API (api.alquran.cloud + CDN) */
function getAudioUrl(edition, surahNum) {
  // استخدام CDN الإسلامي كبديل أساسي (موثوق ومستقر)
  return `https://cdn.islamic.network/quran/audio-surah/128/${edition}/${surahNum}.mp3`;
}

// ============================================================
// MENUS
// ============================================================

function mainMenu(chatId) {
  return markup(
    row(btn('📖 القرآن الكريم', 'quran_menu'), btn('🎧 الاستماع للقرآن', 'audio_menu')),
    row(btn('📚 قصص الأنبياء', 'prophets_menu'), btn('📜 الأذكار', 'azkar_menu')),
    row(btn('📌 الأحاديث', 'hadith'), btn('⚙️ الإعدادات', 'settings'))
  );
}

function quranMenu(page = 0) {
  const perPage = 10;
  const totalPages = Math.ceil(SURAH_NAMES.length / perPage);
  const start = page * perPage;
  const surahs = SURAH_NAMES.slice(start, start + perPage);
  const rows = surahs.map((name, i) => {
    const num = start + i + 1;
    return row(btn(`📖 ${num}. ${name}`, `surah_${num}`));
  });
  const nav = [];
  if (page > 0) nav.push(btn('⬅️ السابق', `quran_page_${page - 1}`));
  nav.push(btn(`🔢 ${page + 1}/${totalPages}`, 'quran_page_info'));
  if (page < totalPages - 1) nav.push(btn('➡️ التالي', `quran_page_${page + 1}`));
  rows.push(nav);
  rows.push(row(btn('🔙 الرجوع للقائمة الرئيسية', 'main_menu')));
  return { reply_markup: { inline_keyboard: rows } };
}

function audioMenu(page = 0) {
  const perPage = 4;
  const totalPages = Math.ceil(RECITERS.length / perPage);
  const start = page * perPage;
  const recs = RECITERS.slice(start, start + perPage);
  const rows = recs.map(r => row(btn(`🎙 ${r.name}`, `reciter_${r.id}`)));
  const nav = [];
  if (page > 0) nav.push(btn('⬅️ السابق', `audio_page_${page - 1}`));
  nav.push(btn(`🔢 ${page + 1}/${totalPages}`, 'audio_page_info'));
  if (page < totalPages - 1) nav.push(btn('➡️ التالي', `audio_page_${page + 1}`));
  rows.push(nav);
  rows.push(row(btn('🔙 الرجوع', 'main_menu')));
  return { reply_markup: { inline_keyboard: rows } };
}

function surahAudioMenu(edition, reciterName, page = 0) {
  const perPage = 10;
  const totalPages = Math.ceil(SURAH_NAMES.length / perPage);
  const start = page * perPage;
  const surahs = SURAH_NAMES.slice(start, start + perPage);
  const rows = surahs.map((name, i) => {
    const num = start + i + 1;
    return row(btn(`🎵 ${num}. ${name}`, `play_${edition}_${num}`));
  });
  const nav = [];
  if (page > 0) nav.push(btn('⬅️ السابق', `suraudio_page_${edition}_${page - 1}`));
  nav.push(btn(`🔢 ${page + 1}/${totalPages}`, 'audio_page_info'));
  if (page < totalPages - 1) nav.push(btn('➡️ التالي', `suraudio_page_${edition}_${page + 1}`));
  rows.push(nav);
  rows.push(row(btn('🔙 العودة للقراء', 'audio_menu'), btn('🔙 الرئيسية', 'main_menu')));
  return { reply_markup: { inline_keyboard: rows } };
}

function prophetsMenu() {
  const rows = [];
  // مجموعات من 3 أنبياء في كل صف
  for (let i = 0; i < PROPHETS.length; i += 3) {
    const group = PROPHETS.slice(i, i + 3);
    rows.push(group.map(p => btn(p.name, p.id)));
  }
  rows.push(row(btn('🔙 الرجوع للقائمة الرئيسية', 'main_menu')));
  return { reply_markup: { inline_keyboard: rows } };
}

function azkarMenu() {
  return markup(
    row(btn('🌅 أذكار الصباح', 'azkar_morning')),
    row(btn('🌇 أذكار المساء', 'azkar_evening')),
    row(btn('🌙 أذكار النوم', 'azkar_sleep')),
    row(btn('🔙 الرجوع', 'main_menu'))
  );
}

// ============================================================
// AZKAR DATA
// ============================================================
const AZKAR = {
  morning: [
    { text: 'اللَّهُمَّ بِكَ أَصْبَحْنَا، وَبِكَ أَمْسَيْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ النُّشُورُ.', count: 1 },
    { text: 'أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لاَ إِلَهَ إِلاَّ اللَّهُ وَحْدَهُ لاَ شَرِيكَ لَهُ.', count: 1 },
    { text: 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ: عَدَدَ خَلْقِهِ، وَرِضَا نَفْسِهِ، وَزِنَةَ عَرْشِهِ، وَمِدَادَ كَلِمَاتِهِ.', count: 3 },
    { text: 'اللَّهُمَّ إِنِّي أَسْأَلُكَ عِلْمًا نَافِعًا، وَرِزْقًا طَيِّبًا، وَعَمَلاً مُتَقَبَّلاً.', count: 1 },
    { text: 'أَعُوذُ بِاللَّهِ السَّمِيعِ الْعَلِيمِ مِنَ الشَّيْطَانِ الرَّجِيمِ.', count: 3 },
    { text: 'بِسْمِ اللَّهِ الَّذِي لاَ يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الأَرْضِ وَلاَ فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ.', count: 3 },
    { text: 'رَضِيتُ بِاللَّهِ رَبًّا، وَبِالْإِسْلَامِ دِينًا، وَبِمُحَمَّدٍ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ نَبِيًّا.', count: 3 },
    { text: 'اللَّهُمَّ أَنْتَ رَبِّي لاَ إِلَهَ إِلاَّ أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ.', count: 1 },
    { text: 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ (مائة مرة)', count: 100 },
    { text: 'لاَ إِلَهَ إِلاَّ اللَّهُ وَحْدَهُ لاَ شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ.', count: 10 },
    { text: 'اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ.', count: 10 },
    { text: 'أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ.', count: 100 },
  ],
  evening: [
    { text: 'اللَّهُمَّ بِكَ أَمْسَيْنَا، وَبِكَ أَصْبَحْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ الْمَصِيرُ.', count: 1 },
    { text: 'أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لاَ إِلَهَ إِلاَّ اللَّهُ وَحْدَهُ لاَ شَرِيكَ لَهُ.', count: 1 },
    { text: 'اللَّهُمَّ إِنِّي أَمْسَيْتُ أُشْهِدُكَ وَأُشْهِدُ حَمَلَةَ عَرْشِكَ وَمَلاَئِكَتَكَ وَجَمِيعَ خَلْقِكَ، أَنَّكَ أَنْتَ اللَّهُ لاَ إِلَهَ إِلاَّ أَنْتَ، وَأَنَّ مُحَمَّدًا عَبْدُكَ وَرَسُولُكَ.', count: 4 },
    { text: 'أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ.', count: 3 },
    { text: 'اللَّهُمَّ عَافِنِي فِي بَدَنِي، اللَّهُمَّ عَافِنِي فِي سَمْعِي، اللَّهُمَّ عَافِنِي فِي بَصَرِي، لاَ إِلَهَ إِلاَّ أَنْتَ.', count: 3 },
    { text: 'بِسْمِ اللَّهِ الَّذِي لاَ يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الأَرْضِ وَلاَ فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ.', count: 3 },
    { text: 'رَضِيتُ بِاللَّهِ رَبًّا، وَبِالْإِسْلَامِ دِينًا، وَبِمُحَمَّدٍ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ نَبِيًّا.', count: 3 },
    { text: 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ (مائة مرة)', count: 100 },
    { text: 'اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ.', count: 10 },
    { text: 'أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ.', count: 100 },
  ],
  sleep: [
    { text: 'بِاسْمِكَ رَبِّي وَضَعْتُ جَنْبِي، وَبِكَ أَرْفَعُهُ، فَإِنْ أَمْسَكْتَ نَفْسِي فَارْحَمْهَا، وَإِنْ أَرْسَلْتَهَا فَاحْفَظْهَا بِمَا تَحْفَظُ بِهِ عِبَادَكَ الصَّالِحِينَ.', count: 1 },
    { text: 'اللَّهُمَّ إِنَّكَ خَلَقْتَ نَفْسِي وَأَنْتَ تَوَفَّاهَا، لَكَ مَمَاتُهَا وَمَحْيَاهَا، فَإِنْ أَحْيَيْتَهَا فَاحْفَظْهَا، وَإِنْ أَمَتَّهَا فَاغْفِرْ لَهَا.', count: 1 },
    { text: 'اللَّهُمَّ قِنِي عَذَابَكَ يَوْمَ تَبْعَثُ عِبَادَكَ.', count: 3 },
    { text: 'بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا.', count: 3 },
    { text: 'سُبْحَانَ اللَّهِ (33 مرة)، الْحَمْدُ لِلَّهِ (33 مرة)، اللَّهُ أَكْبَرُ (34 مرة)', count: 100 },
    { text: 'اللَّهُمَّ رَبَّ السَّمَاوَاتِ السَّبْعِ وَرَبَّ الْعَرْشِ الْعَظِيمِ، رَبَّنَا وَرَبَّ كُلِّ شَيْءٍ...', count: 1 },
    { text: 'آمَنَ الرَّسُولُ بِمَا أُنْزِلَ إِلَيْهِ مِنْ رَبِّهِ وَالْمُؤْمِنُونَ...', count: 1 },
    { text: 'اللَّهُ لاَ إِلَهَ إِلاَّ هُوَ الْحَيُّ الْقَيُّومُ... (آية الكرسي)', count: 1 },
    { text: 'قُلْ هُوَ اللَّهُ أَحَدٌ * اللَّهُ الصَّمَدُ * لَمْ يَلِدْ وَلَمْ يُولَدْ * وَلَمْ يَكُنْ لَهُ كُفُوًا أَحَدٌ.', count: 3 },
    { text: 'قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ...', count: 3 },
    { text: 'قُلْ أَعُوذُ بِرَبِّ النَّاسِ...', count: 3 },
  ],
};

// ============================================================
// HADITH
// ============================================================
async function fetchHadith() {
  return new Promise((resolve) => {
    https.get('https://api.hadith.sutanlab.id/books/bukhari/random?range=1-500', (res) => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => {
        try {
          const j = JSON.parse(d);
          if (j.data && j.data.contents) {
            const h = j.data.contents;
            resolve(`📌 <b>حديث شريف</b>\n\n${h.arab}\n\n📖 رواه ${h.name}` || '');
          } else resolve(null);
        } catch { resolve(null); }
      });
    }).on('error', () => resolve(null));
  });
}

// ============================================================
// MESSAGE HANDLER
// ============================================================
bot.on('message', async (msg) => {
  if (!msg.from || msg.from.is_bot) return;
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (isBanned(userId)) return;

  registerUser(msg);
  const text = (msg.text || '').trim();

  if (text === '/start') {
    const userName = msg.from.first_name || 'الحبيب';
    await bot.sendMessage(chatId, 
      `🌙 <b>السلام عليكم ورحمة الله وبركاته</b>\n\n`
      + `أهلاً بك يا ${userName} في بوت <b>سِرَاجُ السُّنَّة</b> 📖\n\n`
      + `البوت الإسلامي الشامل:\n`
      + `📖 • قراءة القرآن الكريم\n`
      + `🎧 • الاستماع لتلاوات مشاهير القراء\n`
      + `📚 • قصص الأنبياء عليهم السلام\n`
      + `📜 • الأذكار (صباح ومساء ونوم)\n`
      + `📌 • الأحاديث النبوية الشريفة\n\n`
      + `✨ استمتع برحلتك الإيمانية`,
      { ...mainMenu(), parse_mode: 'HTML' }
    );
  } else if (text.startsWith('/broadcast') && isAdmin(userId)) {
    const content = text.replace('/broadcast', '').trim();
    if (!content) return bot.sendMessage(chatId, '⚠️ أدخل النص بعد الأمر مثل:\n/broadcast مرحباً بكم');
    settings.broadcastActive = true;
    saveSettings();
    let sent = 0, failed = 0;
    for (const u of users) {
      try {
        await bot.sendMessage(u.id, `📢 <b>إرسال عام</b>\n\n${content}`, { parse_mode: 'HTML' });
        sent++;
      } catch { failed++; }
    }
    settings.broadcastActive = false;
    saveSettings();
    bot.sendMessage(chatId, `✅ تم الإرسال: ${sent}\n❌ فشل: ${failed}`);
  } else if (text === '/stats' && isAdmin(userId)) {
    bot.sendMessage(chatId,
      `📊 <b>إحصائيات البوت</b>\n\n`
      + `👥 المستخدمون: ${users.length}\n`
      + `🚫 المحظورون: ${banned.length}\n`
      + `👑 المشرفون: ${admins.length}`,
      { parse_mode: 'HTML' }
    );
  } else if (text.startsWith('/ban') && isAdmin(userId)) {
    const parts = text.split(' ');
    const targetId = parseInt(parts[1]);
    if (!targetId) return bot.sendMessage(chatId, '⚠️ استخدم: /ban معرف_